"use client";

import { FormEvent, useMemo, useState } from "react";

type ModuleKey =
  | "dashboard" | "customers" | "projects" | "rfqs" | "sourcing" | "quotes"
  | "comparison" | "approvals" | "orders" | "commissions" | "expenses"
  | "invoices" | "payments" | "suppliers" | "certificates" | "reports"
  | "documents" | "audit" | "settings";

type StatusTone = "green" | "amber" | "red" | "blue" | "slate" | "purple";

const modules: { group: string; items: { key: ModuleKey; label: string; icon: string }[] }[] = [
  { group: "Workspace", items: [
    { key: "dashboard", label: "Dashboard", icon: "⌂" },
    { key: "customers", label: "Customers", icon: "◉" },
    { key: "projects", label: "Projects", icon: "▣" },
  ]},
  { group: "Procurement", items: [
    { key: "rfqs", label: "RFQs", icon: "RF" },
    { key: "sourcing", label: "Supplier Sourcing", icon: "⌕" },
    { key: "quotes", label: "Supplier Quotes", icon: "₹" },
    { key: "comparison", label: "Quote Comparison", icon: "≋" },
    { key: "approvals", label: "Customer Approval", icon: "✓" },
    { key: "orders", label: "Orders & Delivery", icon: "□" },
  ]},
  { group: "Finance", items: [
    { key: "commissions", label: "Commission", icon: "%" },
    { key: "expenses", label: "Expenses", icon: "↗" },
    { key: "invoices", label: "Agent Invoices", icon: "IN" },
    { key: "payments", label: "Payments", icon: "₹" },
  ]},
  { group: "Control", items: [
    { key: "suppliers", label: "Suppliers", icon: "S" },
    { key: "certificates", label: "Certificates", icon: "★" },
    { key: "reports", label: "Reports", icon: "↗" },
    { key: "documents", label: "Documents", icon: "▤" },
    { key: "audit", label: "Audit Log", icon: "◎" },
    { key: "settings", label: "Settings", icon: "⚙" },
  ]},
];

const customers = [
  { name: "Bharat Process Systems", code: "CUS-001", contact: "Rakesh Mehta", projects: 2, rfqs: 3, receivable: "₹3,42,200", status: "Active" },
  { name: "Al Noor Industrial LLC", code: "CUS-002", contact: "Sarah Ahmed", projects: 1, rfqs: 1, receivable: "$4,850", status: "Active" },
  { name: "Nova Engineering Works", code: "CUS-003", contact: "Kunal Shah", projects: 1, rfqs: 2, receivable: "₹0", status: "Onboarding" },
];

const projects = [
  { code: "PRJ-2601", name: "Solvent Extraction Expansion", customer: "Bharat Process Systems", location: "Dahej, Gujarat", status: "Active", progress: 72, value: "₹48.6L", commission: "₹2.18L" },
  { code: "PRJ-2602", name: "PED Vessel Package", customer: "Al Noor Industrial LLC", location: "Dubai, UAE", status: "Procurement", progress: 46, value: "$82,400", commission: "$—" },
  { code: "PRJ-2603", name: "Packaging Line Upgrade", customer: "Bharat Process Systems", location: "Pune, Maharashtra", status: "Delivered", progress: 94, value: "₹18.2L", commission: "₹91,000" },
  { code: "PRJ-2604", name: "Utility Piping Revamp", customer: "Nova Engineering Works", location: "Ahmedabad, Gujarat", status: "RFQ", progress: 18, value: "₹—", commission: "₹—" },
];

const rfqs = [
  { ref: "RFQ-2026-004", title: "SS316 Reactor & Agitator Package", customer: "Bharat Process Systems", project: "PRJ-2601", due: "08 Aug 2026", quotes: "3 / 3", status: "Under Evaluation" },
  { ref: "RFQ-2026-003", title: "PED Pressure Vessel Package", customer: "Al Noor Industrial LLC", project: "PRJ-2602", due: "12 Aug 2026", quotes: "2 / 4", status: "Quote Collection" },
  { ref: "RFQ-2026-002", title: "Conveyor Drive Assembly", customer: "Bharat Process Systems", project: "PRJ-2603", due: "Completed", quotes: "4 / 4", status: "Delivered" },
  { ref: "RFQ-2026-001", title: "Utility Piping & Valves", customer: "Nova Engineering Works", project: "PRJ-2604", due: "18 Aug 2026", quotes: "0 / 5", status: "Issued" },
];

const suppliers = [
  { name: "Apex Process Equipments", location: "Ahmedabad, India", categories: "Reactors, Vessels", rating: "4.8", response: "96%", ontime: "92%", status: "Preferred" },
  { name: "SteelCore Fabrication", location: "Vadodara, India", categories: "SS Fabrication", rating: "4.5", response: "89%", ontime: "86%", status: "Active" },
  { name: "Global Vessel Works", location: "Sharjah, UAE", categories: "PED Vessels", rating: "4.6", response: "91%", ontime: "90%", status: "Active" },
  { name: "Prime Industrial Systems", location: "Pune, India", categories: "Agitators, Drives", rating: "4.1", response: "78%", ontime: "81%", status: "Review" },
  { name: "Delta Engineering Co.", location: "Rajkot, India", categories: "General Fabrication", rating: "3.9", response: "72%", ontime: "76%", status: "Active" },
];

const quoteComparison = [
  { supplier: "Apex Process Equipments", landed: "₹15,86,000", technical: 96, certificates: "Valid", delivery: "10 weeks", warranty: "24 months", payment: "20/70/10", score: 91, decision: "Recommended" },
  { supplier: "SteelCore Fabrication", landed: "₹14,92,500", technical: 88, certificates: "Expiring Soon", delivery: "12 weeks", warranty: "18 months", payment: "30/60/10", score: 79, decision: "Clarification" },
  { supplier: "Prime Industrial Systems", landed: "₹14,45,000", technical: 76, certificates: "Missing PED", delivery: "9 weeks", warranty: "12 months", payment: "40/50/10", score: 61, decision: "Blocked" },
];

const orders = [
  { ref: "ORD-26003", rfq: "RFQ-2026-002", supplier: "Apex Process Equipments", customer: "Bharat Process Systems", value: "₹18,20,000", eta: "Delivered 26 Jul", status: "Customer Accepted" },
  { ref: "ORD-26002", rfq: "RFQ-2026-003", supplier: "Global Vessel Works", customer: "Al Noor Industrial LLC", value: "$82,400", eta: "18 Sep 2026", status: "In Production" },
  { ref: "ORD-26001", rfq: "RFQ-2026-004", supplier: "Apex Process Equipments", customer: "Bharat Process Systems", value: "₹15,86,000", eta: "12 Oct 2026", status: "Supplier Confirmed" },
];

const commissions = [
  { ref: "COM-26003", customer: "Bharat Process Systems", order: "ORD-26003", basis: "5% of eligible value", amount: "₹91,000", confirmed: "30 Jul 2026", status: "Confirmed" },
  { ref: "COM-26002", customer: "Al Noor Industrial LLC", order: "ORD-26002", basis: "Flat", amount: "$4,850", confirmed: "—", status: "Awaiting Completion" },
  { ref: "COM-26001", customer: "Bharat Process Systems", order: "ORD-26001", basis: "Customer to define", amount: "₹—", confirmed: "—", status: "Awaiting Completion" },
];

const expenses = [
  { ref: "EXP-26014", customer: "Bharat Process Systems", project: "PRJ-2603", category: "Inspection Travel", amount: "₹12,800", reimbursable: "Yes", status: "Approved" },
  { ref: "EXP-26013", customer: "Al Noor Industrial LLC", project: "PRJ-2602", category: "Courier & Documentation", amount: "$180", reimbursable: "Yes", status: "Submitted" },
  { ref: "EXP-26012", customer: "Bharat Process Systems", project: "PRJ-2601", category: "Local Travel", amount: "₹4,200", reimbursable: "No", status: "Internal" },
];

const invoices = [
  { number: "AGI-2026-018", customer: "Bharat Process Systems", project: "PRJ-2603", commission: "₹91,000", expenses: "₹12,800", tax: "₹18,684", total: "₹1,22,484", balance: "₹42,484", status: "Partially Paid" },
  { number: "AGI-2026-017", customer: "Al Noor Industrial LLC", project: "PRJ-2602", commission: "$4,850", expenses: "$180", tax: "$0", total: "$5,030", balance: "$5,030", status: "Draft" },
  { number: "AGI-2026-016", customer: "Bharat Process Systems", project: "PRJ-2601", commission: "₹1,27,500", expenses: "₹8,400", tax: "₹24,462", total: "₹1,60,362", balance: "₹0", status: "Paid" },
];

const certificates = [
  { supplier: "Apex Process Equipments", type: "ISO 9001:2015", number: "IN-QMS-28411", expiry: "18 May 2027", scope: "Design & fabrication", status: "Valid" },
  { supplier: "Apex Process Equipments", type: "PED Module H", number: "PED-H-11902", expiry: "14 Feb 2027", scope: "Pressure equipment", status: "Valid" },
  { supplier: "SteelCore Fabrication", type: "ISO 3834-2", number: "WQ-93884", expiry: "22 Aug 2026", scope: "Fusion welding", status: "Expiring Soon" },
  { supplier: "Prime Industrial Systems", type: "PED Compliance", number: "—", expiry: "—", scope: "Required for RFQ-2026-004", status: "Missing" },
  { supplier: "Delta Engineering Co.", type: "ISO 9001:2015", number: "QMS-12008", expiry: "30 Jun 2026", scope: "Fabrication", status: "Expired" },
];

function tone(status: string): StatusTone {
  const s = status.toLowerCase();
  if (s.includes("paid") || s.includes("valid") || s.includes("approved") || s.includes("accepted") || s.includes("confirmed") || s.includes("preferred")) return "green";
  if (s.includes("await") || s.includes("expiring") || s.includes("collection") || s.includes("evaluation") || s.includes("review") || s.includes("partial")) return "amber";
  if (s.includes("missing") || s.includes("expired") || s.includes("blocked") || s.includes("rejected")) return "red";
  if (s.includes("production") || s.includes("active") || s.includes("issued") || s.includes("procurement") || s.includes("delivered")) return "blue";
  if (s.includes("draft") || s.includes("internal") || s.includes("onboarding")) return "slate";
  return "purple";
}

function Badge({ children }: { children: string }) {
  return <span className={`badge badge-${tone(children)}`}>{children}</span>;
}

function Login({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState("admin@procureflow.demo");
  const [password, setPassword] = useState("Demo@123");
  const [error, setError] = useState("");
  const [show, setShow] = useState(false);
  function submit(e: FormEvent) {
    e.preventDefault();
    if (email === "admin@procureflow.demo" && password === "Demo@123") onLogin();
    else setError("Use the demo credentials shown below.");
  }
  return <main className="login-shell">
    <section className="login-brand">
      <div className="brand"><span className="brand-mark">PF</span><div><strong>ProcureFlow Agent</strong><small>Procurement & Commission Desk</small></div></div>
      <div className="login-copy"><span className="eyebrow">CONTROL. COMPARE. CLOSE.</span><h1>One clear desk for every RFQ, supplier and customer-confirmed commission.</h1>
        <ul><li>Compare price, compliance, certificates and delivery together.</li><li>Supplier bills the customer directly—material never enters the agent invoice.</li><li>Commission is confirmed by the customer only after completion.</li></ul></div>
      <p className="login-foot">Demo workspace · Real business rules · No live customer data</p>
    </section>
    <section className="login-panel"><form className="login-card" onSubmit={submit}><div className="mobile-brand"><span className="brand-mark">PF</span><strong>ProcureFlow Agent</strong></div><span className="eyebrow teal">SECURE WORKSPACE</span><h2>Welcome back</h2><p>Sign in to manage procurement and commission workflows.</p>
      <label>Work email<input value={email} onChange={e=>setEmail(e.target.value)} type="email" /></label>
      <label>Password<div className="password-row"><input value={password} onChange={e=>setPassword(e.target.value)} type={show ? "text" : "password"}/><button type="button" onClick={()=>setShow(!show)}>{show ? "Hide" : "Show"}</button></div></label>
      <div className="login-options"><label className="check"><input type="checkbox" defaultChecked/> Remember me</label><button type="button" className="link-btn">Forgot password?</button></div>
      {error && <div className="form-error">{error}</div>}<button className="primary full" type="submit">Sign in securely →</button>
      <div className="demo-box"><strong>Demo credentials</strong><span>admin@procureflow.demo</span><span>Demo@123</span></div><small className="security">● Protected demo session</small>
    </form></section>
  </main>;
}

function PageHeader({ title, subtitle, action, onAction }: { title: string; subtitle: string; action?: string; onAction?: () => void }) {
  return <div className="page-header"><div><span className="eyebrow teal">PROCUREFLOW / {title.toUpperCase()}</span><h1>{title}</h1><p>{subtitle}</p></div>{action && <button className="primary" onClick={onAction}>＋ {action}</button>}</div>;
}

function Stat({ label, value, sub, accent="teal" }: { label:string; value:string; sub:string; accent?:string }) {
  return <article className={`stat stat-${accent}`}><span>{label}</span><strong>{value}</strong><small>{sub}</small></article>;
}

function Table({ heads, rows }: { heads:string[]; rows:(string | {badge:string})[][] }) {
  return <div className="table-wrap"><table><thead><tr>{heads.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((row,i)=><tr key={i}>{row.map((c,j)=><td key={j}>{typeof c === "string" ? c : <Badge>{c.badge}</Badge>}</td>)}</tr>)}</tbody></table></div>;
}

function Toolbar({ placeholder="Search records..." }: { placeholder?:string }) {
  return <div className="toolbar"><div className="searchbox">⌕<input placeholder={placeholder}/></div><select><option>All statuses</option><option>Active</option><option>Pending</option><option>Completed</option></select><select><option>All customers</option>{customers.map(c=><option key={c.code}>{c.name}</option>)}</select><button className="ghost">⇩ Export</button></div>;
}

function Dashboard({ navigate }: { navigate:(k:ModuleKey)=>void }) {
  return <><PageHeader title="Command Centre" subtitle="Friday, 31 July 2026 · Here is what needs your attention today." action="New RFQ" onAction={()=>navigate("rfqs")}/>
    <div className="stats-grid"><Stat label="Active Customers" value="3" sub="4 projects running"/><Stat label="Open RFQs" value="4" sub="7 supplier responses" accent="blue"/><Stat label="Orders in progress" value="3" sub="₹82.6L tracked value" accent="purple"/><Stat label="Pending acceptance" value="1" sub="Action due today" accent="amber"/><Stat label="Awaiting commission" value="2" sub="After order completion" accent="amber"/><Stat label="Commission earned" value="₹3.09L" sub="This financial year" accent="green"/><Stat label="Invoice receivable" value="₹3.42L" sub="₹42,484 overdue" accent="red"/><Stat label="Certificates at risk" value="3" sub="1 expired · 1 missing" accent="red"/></div>
    <div className="dashboard-grid"><section className="panel span-2"><div className="panel-head"><div><h3>RFQ pipeline</h3><p>Movement from issue to completed order</p></div><button className="link-btn" onClick={()=>navigate("rfqs")}>View all →</button></div><div className="funnel">{[["Issued",4,100],["Quotes received",3,76],["Evaluated",2,54],["Approved",2,42],["Ordered",1,28]].map(x=><div key={String(x[0])}><span>{x[0]}</span><div><i style={{width:`${x[2]}%`}}></i></div><strong>{x[1]}</strong></div>)}</div></section>
      <section className="panel"><div className="panel-head"><div><h3>Attention required</h3><p>Prioritised operational tasks</p></div></div><div className="task-list"><button onClick={()=>navigate("certificates")}><b className="risk-dot red"></b><span><strong>PED certificate missing</strong><small>Prime Industrial · RFQ-2026-004</small></span><em>High</em></button><button onClick={()=>navigate("commissions")}><b className="risk-dot amber"></b><span><strong>Commission confirmation due</strong><small>ORD-26003 · Bharat Process</small></span><em>Today</em></button><button onClick={()=>navigate("invoices")}><b className="risk-dot blue"></b><span><strong>Invoice payment overdue</strong><small>AGI-2026-018 · ₹42,484</small></span><em>5d</em></button></div></section>
      <section className="panel span-2"><div className="panel-head"><div><h3>Commission vs reimbursable expense</h3><p>Six-month performance (₹ lakh)</p></div></div><div className="bar-chart">{[["Feb",38,10],["Mar",52,16],["Apr",44,12],["May",68,20],["Jun",61,14],["Jul",82,24]].map(x=><div key={String(x[0])}><div><i style={{height:`${x[1]}%`}}></i><b style={{height:`${x[2]}%`}}></b></div><span>{x[0]}</span></div>)}</div><div className="legend"><span><i className="teal-bg"></i>Commission</span><span><i className="gold-bg"></i>Approved expenses</span></div></section>
      <section className="panel"><div className="panel-head"><div><h3>Recent activity</h3><p>Latest verified actions</p></div></div><div className="timeline"><div><i></i><p><strong>Customer accepted delivery</strong><small>ORD-26003 · 18 min ago</small></p></div><div><i></i><p><strong>Quote revision received</strong><small>Apex · RFQ-2026-004 · 1h</small></p></div><div><i></i><p><strong>Expense approved</strong><small>EXP-26014 · 3h ago</small></p></div><div><i></i><p><strong>Payment recorded</strong><small>₹80,000 · AGI-2026-018</small></p></div></div></section>
    </div></>;
}

function Customers() { return <><PageHeader title="Customers" subtitle="Manage customer accounts, projects, RFQs and commission receivables." action="Add Customer"/><Toolbar placeholder="Search customers or contacts..."/><section className="panel"><Table heads={["Customer","Code","Primary contact","Projects","Open RFQs","Agent receivable","Status"]} rows={customers.map(c=>[c.name,c.code,c.contact,String(c.projects),String(c.rfqs),c.receivable,{badge:c.status}])}/></section></>; }
function Projects() { return <><PageHeader title="Projects" subtitle="Customer-wise procurement progress and financial position." action="New Project"/><Toolbar placeholder="Search project name or code..."/><div className="card-grid">{projects.map(p=><article className="project-card" key={p.code}><div><Badge>{p.status}</Badge><span className="code">{p.code}</span></div><h3>{p.name}</h3><p>{p.customer}</p><small>⌖ {p.location}</small><div className="progress"><span><b>Progress</b><em>{p.progress}%</em></span><div><i style={{width:`${p.progress}%`}}></i></div></div><dl><div><dt>Supplier-direct value</dt><dd>{p.value}</dd></div><div><dt>Confirmed commission</dt><dd>{p.commission}</dd></div></dl><button className="secondary full">Open project workspace →</button></article>)}</div></>; }

function RFQs() {
  const [wizard,setWizard]=useState(false); const [step,setStep]=useState(1);
  return <><PageHeader title="Requests for Quotation" subtitle="Control customer requirements, item specifications, design revisions and supplier invitations." action="Create RFQ" onAction={()=>setWizard(true)}/><Toolbar placeholder="Search RFQ reference or item..."/><section className="panel"><Table heads={["RFQ","Requirement","Customer / Project","Due date","Quotes","Status"]} rows={rfqs.map(r=>[r.ref,r.title,`${r.customer} · ${r.project}`,r.due,r.quotes,{badge:r.status}])}/></section>
  {wizard&&<div className="modal-backdrop"><div className="modal large"><div className="modal-head"><div><span className="eyebrow teal">NEW REQUEST FOR QUOTATION</span><h2>Create RFQ</h2></div><button onClick={()=>setWizard(false)}>×</button></div><div className="steps">{["Customer & project","RFQ details","Line items","Documents","Suppliers","Review"].map((s,i)=><div className={step===i+1?"active":step>i+1?"done":""} key={s}><i>{step>i+1?"✓":i+1}</i><span>{s}</span></div>)}</div><div className="modal-body"><div className="rule-banner blue-rule"><strong>Step {step} of 6</strong><span>{["Select the requesting customer and project.","Enter commercial and delivery requirements.","Add item specification, quantity and target date.","Upload drawings, BOQ and revision-controlled documents.","Shortlist suppliers based on capabilities.","Review all information before issue."][step-1]}</span></div>{step===1&&<div className="form-grid"><label>Customer<select><option>Bharat Process Systems</option><option>Al Noor Industrial LLC</option></select></label><label>Project<select><option>PRJ-2601 · Solvent Extraction Expansion</option></select></label><label>Customer RFQ reference<input placeholder="Customer reference"/></label><label>Contact person<input defaultValue="Rakesh Mehta"/></label></div>}{step===2&&<div className="form-grid"><label className="wide">RFQ title<input defaultValue="SS316 Reactor & Agitator Package"/></label><label>Issue date<input type="date"/></label><label>Due date<input type="date"/></label><label>Currency<select><option>INR</option><option>USD</option></select></label><label>Delivery location<input defaultValue="Dahej, Gujarat"/></label></div>}{step===3&&<div><Table heads={["Item","Specification","Qty","UOM","Required by"]} rows={[["SS316 Reactor 10KL","Design pressure 6 bar; PED compliant","1","No.","30 Sep 2026"],["Top Entry Agitator","15kW, VFD-ready, mech seal","1","No.","30 Sep 2026"]]}/><button className="secondary">＋ Add line item</button></div>}{step===4&&<div className="dropzone"><strong>Drop drawings, BOQ, datasheets or reference files here</strong><span>PDF, XLSX, DWG, STEP, JPG · Revision control enabled</span><button className="secondary">Choose files</button></div>}{step===5&&<div className="supplier-checks">{suppliers.slice(0,4).map((s,i)=><label key={s.name}><input type="checkbox" defaultChecked={i<3}/><span><strong>{s.name}</strong><small>{s.location} · {s.categories}</small></span><Badge>{s.status}</Badge></label>)}</div>}{step===6&&<div className="review-box"><h3>RFQ ready for issue</h3><dl><div><dt>Customer</dt><dd>Bharat Process Systems</dd></div><div><dt>Project</dt><dd>PRJ-2601</dd></div><div><dt>Line items</dt><dd>2</dd></div><div><dt>Invited suppliers</dt><dd>3</dd></div><div><dt>Attachments</dt><dd>4 documents</dd></div><div><dt>Due date</dt><dd>08 Aug 2026</dd></div></dl></div>}</div><div className="modal-actions"><button className="ghost" onClick={()=>setStep(Math.max(1,step-1))} disabled={step===1}>← Back</button><button className="secondary" onClick={()=>setWizard(false)}>Save draft</button><button className="primary" onClick={()=>step<6?setStep(step+1):setWizard(false)}>{step<6?"Continue →":"Issue RFQ"}</button></div></div></div>}</>;
}

function Sourcing(){return <><PageHeader title="Supplier Sourcing" subtitle="Build qualified shortlists by capability, certification, performance and location." action="Start Sourcing"/><div className="sourcing-layout"><section className="panel"><Toolbar placeholder="Search capability, material or location..."/><Table heads={["Supplier","Location","Capability","Rating","Response","On-time","Status"]} rows={suppliers.map(s=>[s.name,s.location,s.categories,s.rating,s.response,s.ontime,{badge:s.status}])}/></section><aside className="panel shortlist"><h3>RFQ-2026-004 shortlist</h3><p>SS316 Reactor & Agitator Package</p>{suppliers.slice(0,3).map((s,i)=><div key={s.name}><span>{i+1}</span><p><strong>{s.name}</strong><small>{s.categories}</small></p><Badge>{i===0?"Strong Match":i===1?"Review":"Certificate Risk"}</Badge></div>)}<button className="primary full">Send RFQ invitation</button></aside></div></>}

function Quotes(){return <><PageHeader title="Supplier Quotes" subtitle="Capture commercial revisions, landed cost, deviations and attached compliance evidence." action="Add Supplier Quote"/><div className="rule-banner"><strong>RFQ-2026-004 · Latest revisions</strong><span>All values below are supplier quotations to the customer. They are not agent revenue.</span></div><Toolbar placeholder="Search supplier or quote reference..."/><section className="panel"><Table heads={["Supplier","Revision","Base price","Freight & packing","Tax","Landed cost","Lead time","Validity","Status"]} rows={[["Apex Process Equipments","Rev 02","₹13,20,000","₹28,000","₹2,38,000","₹15,86,000","10 weeks","28 days",{badge:"Complete"}],["SteelCore Fabrication","Rev 01","₹12,40,000","₹31,500","₹2,21,000","₹14,92,500","12 weeks","21 days",{badge:"Certificate Review"}],["Prime Industrial Systems","Rev 03","₹11,92,000","₹38,000","₹2,15,000","₹14,45,000","9 weeks","15 days",{badge:"Compliance Risk"}]]}/></section></>}

function Comparison(){return <><PageHeader title="Quote Comparison" subtitle="RFQ-2026-004 · Evidence-based supplier evaluation and customer recommendation." action="Export Comparison"/><div className="weights"><span>Scoring weights</span>{[["Technical",30],["Certificates",20],["Landed Cost",25],["Delivery",10],["Performance",10],["Commercial",5]].map(x=><div key={String(x[0])}><b>{x[0]}</b><strong>{x[1]}%</strong></div>)}</div><section className="panel comparison"><Table heads={["Evaluation criterion",...quoteComparison.map(q=>q.supplier)]} rows={[
      ["Landed cost",...quoteComparison.map(q=>q.landed)],["Technical compliance",...quoteComparison.map(q=>`${q.technical}%`)],["Required certificates",...quoteComparison.map(q=>({badge:q.certificates}))],["Delivery",...quoteComparison.map(q=>q.delivery)],["Warranty",...quoteComparison.map(q=>q.warranty)],["Payment terms",...quoteComparison.map(q=>q.payment)],["Weighted score",...quoteComparison.map(q=>`${q.score} / 100`)],["Decision",...quoteComparison.map(q=>({badge:q.decision}))],
    ]}/></section><div className="ai-grid"><section className="panel ai-panel"><div className="panel-head"><div><span className="eyebrow teal">AI DECISION SUPPORT</span><h3>Structured supplier evaluation</h3><p>Final approval remains with the customer.</p></div><Badge>Evidence Based</Badge></div><div className="ai-recommend"><span>01</span><div><strong>Apex Process Equipments</strong><p>Highest combined score with full technical compliance, valid ISO/PED evidence and stronger warranty. Premium over lowest quote is justified by lower compliance risk.</p></div><em>91/100</em></div><div className="insights"><div><h4>Strengths</h4><ul><li>Full specification compliance</li><li>Verified PED and ISO coverage</li><li>24-month warranty</li></ul></div><div><h4>Risks</h4><ul><li>₹1.41L above lowest quote</li><li>10-week manufacturing lead</li></ul></div><div><h4>Missing information</h4><ul><li>Final QAP approval date</li><li>Third-party inspection slot</li></ul></div></div></section><section className="panel"><h3>Recommendation control</h3><p className="muted">The agent recommends; the customer makes the final decision.</p><label>Recommended supplier<select><option>Apex Process Equipments</option></select></label><label>Rationale<textarea defaultValue="Best compliant offer with valid PED evidence, strongest warranty and acceptable delivery. Lowest lifecycle and certification risk."/></label><button className="primary full">Send recommendation to customer →</button></section></div></>}

function Approvals(){return <><PageHeader title="Supplier Selection & Customer Approval" subtitle="Record the customer’s decision with approver, evidence and immutable history."/><div className="approval-card"><div className="approval-top"><div><span className="eyebrow teal">RFQ-2026-004</span><h2>SS316 Reactor & Agitator Package</h2><p>Bharat Process Systems · PRJ-2601</p></div><Badge>Approved</Badge></div><div className="approval-flow"><div className="done"><i>✓</i><span><strong>Agent recommendation</strong><small>31 Jul · Apex Process Equipments</small></span></div><div className="done"><i>✓</i><span><strong>Customer technical review</strong><small>02 Aug · Rakesh Mehta</small></span></div><div className="done"><i>✓</i><span><strong>Commercial approval</strong><small>03 Aug · Procurement Head</small></span></div><div><i>4</i><span><strong>Customer PO</strong><small>Awaiting PO reference</small></span></div></div><div className="approval-detail"><dl><div><dt>Approved supplier</dt><dd>Apex Process Equipments</dd></div><div><dt>Approved landed value</dt><dd>₹15,86,000</dd></div><div><dt>Customer approver</dt><dd>Rakesh Mehta</dd></div><div><dt>Approval evidence</dt><dd>Customer_Approval_030826.pdf</dd></div></dl><blockquote>“Proceed with Apex based on complete PED compliance and agreed delivery. Issue PO after final drawing approval.”</blockquote></div></div></>}

function Orders(){return <><PageHeader title="Orders & Delivery" subtitle="Track customer PO, supplier invoice, dispatch, receipt and customer acceptance." action="Add Order"/><div className="rule-banner red-rule"><strong>Supplier invoices customer directly</strong><span>Material value is tracked for procurement control only and is excluded from every agent invoice.</span></div><Toolbar placeholder="Search order, RFQ or supplier..."/><section className="panel"><Table heads={["Order","RFQ","Supplier","Customer","Material value (tracking only)","ETA","Status"]} rows={orders.map(o=>[o.ref,o.rfq,o.supplier,o.customer,o.value,o.eta,{badge:o.status}])}/></section><section className="panel order-detail"><div className="panel-head"><div><span className="eyebrow teal">ORD-26003</span><h3>Delivery and acceptance timeline</h3></div><Badge>Customer Accepted</Badge></div><div className="order-steps">{["Selected","Customer PO","Supplier Confirmed","In Production","Dispatched","Delivered","Customer Accepted","Completed"].map((s,i)=><div className={i<7?"done":""} key={s}><i>{i<7?"✓":i+1}</i><span>{s}</span><small>{i<7?["08 Jun","10 Jun","12 Jun","14 Jun","22 Jul","26 Jul","30 Jul"][i]:"Pending"}</small></div>)}</div></section></>}

function Commissions(){return <><PageHeader title="Commission Confirmation" subtitle="Customer-defined commission becomes eligible only after accepted delivery or completion." action="Record Confirmation"/><div className="rule-banner green-rule"><strong>Commission is defined and confirmed by the customer after order completion</strong><span>Agent entry requires customer evidence. Confirmed values cannot be silently edited.</span></div><Toolbar placeholder="Search commission, order or customer..."/><section className="panel"><Table heads={["Commission","Customer","Order","Customer-defined basis","Amount","Confirmed on","Status"]} rows={commissions.map(c=>[c.ref,c.customer,c.order,c.basis,c.amount,c.confirmed,{badge:c.status}])}/></section><div className="form-panel"><div><span className="eyebrow teal">CONFIRMATION RECORD</span><h3>COM-26003 · Customer confirmed</h3><p>Recorded from customer evidence after order acceptance.</p></div><div className="form-grid"><label>Customer<input value="Bharat Process Systems" readOnly/></label><label>Order<input value="ORD-26003" readOnly/></label><label>Commission basis<select><option>Percentage</option></select></label><label>Eligible reference value<input value="₹18,20,000" readOnly/></label><label>Customer-defined rate<input value="5.00%" readOnly/></label><label>Final commission<input value="₹91,000" readOnly/></label><label>Customer approver<input value="Rakesh Mehta" readOnly/></label><label>Evidence<input value="Commission_Approval_300726.pdf" readOnly/></label></div><div className="lock-note">🔒 Confirmed value locked · Amendment requires reason, new evidence and audit entry.</div></div></>}

function Expenses(){return <><PageHeader title="Expenses" subtitle="Track customer/project expenses and reimbursable approval evidence." action="Add Expense"/><div className="rule-banner"><strong>Invoice eligibility rule</strong><span>Only expenses marked Reimbursable and Approved by the customer can be included in an agent invoice.</span></div><Toolbar/><section className="panel"><Table heads={["Expense","Customer","Project","Category","Amount","Reimbursable","Approval status"]} rows={expenses.map(e=>[e.ref,e.customer,e.project,e.category,e.amount,e.reimbursable,{badge:e.status}])}/></section></>}

function Invoices(){return <><PageHeader title="Agent Invoices" subtitle="Invoice confirmed commission and approved reimbursables—never supplier material value." action="Create Agent Invoice"/><div className="invoice-summary"><Stat label="Draft" value="1" sub="$5,030 prepared"/><Stat label="Issued" value="3" sub="₹3.42L receivable" accent="blue"/><Stat label="Overdue" value="1" sub="₹42,484 outstanding" accent="red"/><Stat label="Paid YTD" value="₹8.76L" sub="12 invoices" accent="green"/></div><Toolbar/><section className="panel"><Table heads={["Invoice","Customer / Project","Confirmed commission","Approved expenses","Tax","Invoice total","Balance","Status"]} rows={invoices.map(i=>[i.number,`${i.customer} · ${i.project}`,i.commission,i.expenses,i.tax,i.total,i.balance,{badge:i.status}])}/></section><section className="invoice-builder"><div className="invoice-paper"><div className="invoice-title"><div><span className="brand-mark">PF</span><strong>ProcureFlow Agent</strong></div><h2>AGENT INVOICE</h2></div><div className="bill-row"><div><small>BILL TO</small><strong>Bharat Process Systems</strong><span>PRJ-2603 · Packaging Line Upgrade</span></div><div><small>INVOICE</small><strong>AGI-2026-018</strong><span>Due 15 Aug 2026</span></div></div><table><thead><tr><th>Description</th><th>Reference</th><th>Amount</th></tr></thead><tbody><tr><td><strong>Confirmed agent commission</strong><small>Customer-confirmed after acceptance</small></td><td>COM-26003</td><td>₹91,000</td></tr><tr><td><strong>Approved reimbursable expense</strong><small>Inspection travel</small></td><td>EXP-26014</td><td>₹12,800</td></tr></tbody></table><div className="excluded"><strong>Excluded from agent invoice</strong><span>Supplier material value · ORD-26003</span><em>₹18,20,000 · Not billable by agent</em></div><div className="invoice-total"><span>Subtotal <b>₹1,03,800</b></span><span>GST 18% <b>₹18,684</b></span><strong>Total <b>₹1,22,484</b></strong><span>Paid <b>₹80,000</b></span><strong className="due">Balance due <b>₹42,484</b></strong></div></div></section></>}

function Payments(){return <><PageHeader title="Payments" subtitle="Allocate customer payments against agent invoices and maintain an auditable ledger." action="Record Payment"/><Toolbar/><section className="panel"><Table heads={["Payment date","Reference","Customer","Agent invoice","Method","Amount","Balance after","Status"]} rows={[["30 Jul 2026","PAY-26038","Bharat Process Systems","AGI-2026-018","Bank transfer","₹80,000","₹42,484",{badge:"Allocated"}],["18 Jul 2026","PAY-26037","Bharat Process Systems","AGI-2026-016","Bank transfer","₹1,60,362","₹0",{badge:"Paid"}],["30 Jun 2026","PAY-26034","Nova Engineering Works","AGI-2026-014","UPI","₹58,410","₹0",{badge:"Paid"}]]}/></section></>}

function Suppliers(){return <><PageHeader title="Suppliers" subtitle="Capability, commercial responsiveness, delivery performance and compliance evidence." action="Add Supplier"/><Toolbar placeholder="Search supplier, category or location..."/><section className="panel"><Table heads={["Supplier","Location","Capabilities","Rating","Response rate","On-time delivery","Status"]} rows={suppliers.map(s=>[s.name,s.location,s.categories,s.rating,s.response,s.ontime,{badge:s.status}])}/></section></>}
function Certificates(){return <><PageHeader title="Certificates" subtitle="Verify supplier compliance and prevent expired or missing evidence from passing evaluation." action="Add Certificate"/><div className="stats-grid compact"><Stat label="Valid" value="12" sub="Verified evidence" accent="green"/><Stat label="Expiring soon" value="2" sub="Within 60 days" accent="amber"/><Stat label="Expired" value="1" sub="Supplier action required" accent="red"/><Stat label="Missing" value="1" sub="Blocks recommendation" accent="red"/></div><Toolbar/><section className="panel"><Table heads={["Supplier","Certificate","Number","Expiry","Scope","Verification"]} rows={certificates.map(c=>[c.supplier,c.type,c.number,c.expiry,c.scope,{badge:c.status}])}/></section></>}

const reportList=["Executive Summary","Customer & Project Summary","RFQ Funnel & Conversion","Supplier Performance","Certificate Expiry","Order & Delivery Status","Commission Awaiting Confirmation","Confirmed / Invoiced / Paid Commission","Expense & Reimbursement","Agent Invoice Register","Receivables & Aging","Payment Collection","Tax Summary","Customer Ledger","Project Profitability","Audit Trail"];
function Reports(){const [report,setReport]=useState("Executive Summary");return <><PageHeader title="Reports" subtitle="Operational, compliance and agent-finance reporting with customer/project filters." action="Export PDF"/><div className="report-layout"><aside className="report-menu">{reportList.map(r=><button className={report===r?"active":""} onClick={()=>setReport(r)} key={r}>{r}<span>›</span></button>)}</aside><section><div className="report-filters"><select><option>01 Jul – 31 Jul 2026</option></select><select><option>All customers</option></select><select><option>All projects</option></select><select><option>All currencies</option></select><button className="ghost">⇩ CSV</button></div><div className="page-header report-title"><div><span className="eyebrow teal">SELECTED REPORT</span><h1>{report}</h1><p>Updated 31 July 2026 at 15:30 IST</p></div></div><div className="stats-grid compact"><Stat label="Customer-direct order value" value="₹82.6L" sub="Tracked; not agent revenue" accent="blue"/><Stat label="Confirmed commission" value="₹3.09L" sub="Customer-approved" accent="green"/><Stat label="Approved expenses" value="₹21,200" sub="Reimbursable only" accent="amber"/><Stat label="Agent receivable" value="₹3.42L" sub="Across issued invoices" accent="red"/></div><section className="panel report-chart"><div className="panel-head"><div><h3>{report} trend</h3><p>Monthly performance view</p></div></div><div className="line-bars">{[42,58,48,72,66,88,78,92].map((n,i)=><div key={i}><i style={{height:`${n}%`}}></i><span>{["Dec","Jan","Feb","Mar","Apr","May","Jun","Jul"][i]}</span></div>)}</div></section><section className="panel"><Table heads={["Customer","Projects","Open RFQs","Tracked order value","Confirmed commission","Agent receivable"]} rows={[["Bharat Process Systems","2","3","₹48.6L","₹3.09L","₹3.42L"],["Al Noor Industrial LLC","1","1","$82,400","$4,850","$5,030"],["Nova Engineering Works","1","2","₹—","₹—","₹0"]]}/></section></section></div></>}

function Documents(){return <><PageHeader title="Documents" subtitle="Central revision-controlled repository across RFQs, suppliers, orders and commission evidence." action="Upload Document"/><Toolbar placeholder="Search filename, reference or owner..."/><section className="panel"><Table heads={["Document","Type","Linked record","Revision","Owner","Updated","Status"]} rows={[["Reactor_GA_RevC.pdf","Design drawing","RFQ-2026-004","Rev C","Bharat Process","30 Jul",{badge:"Current"}],["Apex_PED_Module_H.pdf","Certificate","Apex Process","Rev 0","Procurement","28 Jul",{badge:"Verified"}],["Commission_Approval_300726.pdf","Customer evidence","COM-26003","Rev 0","Finance","30 Jul",{badge:"Locked"}],["Delivery_Note_26003.pdf","Delivery proof","ORD-26003","Rev 0","Operations","26 Jul",{badge:"Accepted"}]]}/></section></>}
function Audit(){return <><PageHeader title="Activity & Audit Log" subtitle="Immutable business history for recommendations, approvals, commission and invoices."/><Toolbar placeholder="Search actor, action or record..."/><section className="panel audit-list">{[["15:18","Manan Shastri","Recorded customer acceptance","ORD-26003","Delivered → Customer Accepted"],["14:42","Rakesh Mehta","Confirmed commission basis","COM-26003","Pending → Confirmed · 5%"],["12:15","Manan Shastri","Uploaded revised supplier quote","RFQ-2026-004","Apex Rev 01 → Rev 02"],["10:34","Finance Admin","Allocated customer payment","AGI-2026-018","₹80,000 allocated"],["09:50","System","Certificate risk detected","Prime Industrial","PED evidence missing"]].map(x=><div key={x[0]}><time>{x[0]}</time><span className="avatar">{x[1].split(" ").map(n=>n[0]).join("").slice(0,2)}</span><p><strong>{x[2]}</strong><small>{x[1]} · {x[3]}</small></p><em>{x[4]}</em></div>)}</section></>}
function Settings(){return <><PageHeader title="Settings" subtitle="Agent organisation, scoring, invoice and workflow controls."/><div className="settings-grid"><section className="panel"><h3>Agent company profile</h3><div className="form-grid"><label>Company name<input defaultValue="ProcureFlow Agent Services"/></label><label>Tax ID / GSTIN<input defaultValue="24ABCDE1234F1Z5"/></label><label className="wide">Registered address<textarea defaultValue="Gujarat, India"/></label><label>Base currency<select><option>INR</option><option>USD</option></select></label><label>Default tax<select><option>GST 18%</option></select></label></div><button className="primary">Save profile</button></section><section className="panel"><h3>Protected business rules</h3><div className="protected-rule"><span>✓</span><p><strong>Supplier-direct material invoicing</strong><small>Supplier material cost cannot be placed in an agent invoice.</small></p><em>Always on</em></div><div className="protected-rule"><span>✓</span><p><strong>Customer-defined commission</strong><small>Commission requires completion and customer evidence.</small></p><em>Always on</em></div><div className="protected-rule"><span>✓</span><p><strong>Compliance recommendation gate</strong><small>Missing mandatory evidence blocks recommendation.</small></p><em>Always on</em></div></section><section className="panel span-2"><h3>Supplier evaluation weights</h3><div className="weight-settings">{[["Technical compliance",30],["Certificates",20],["Landed cost",25],["Delivery",10],["Quality & performance",10],["Commercial terms",5]].map(x=><label key={String(x[0])}><span>{x[0]}</span><input type="range" defaultValue={Number(x[1])}/><strong>{x[1]}%</strong></label>)}</div></section></div></>}

function ModuleView({ active, navigate }:{active:ModuleKey;navigate:(k:ModuleKey)=>void}) {
  const map:Record<ModuleKey,React.ReactNode>={dashboard:<Dashboard navigate={navigate}/>,customers:<Customers/>,projects:<Projects/>,rfqs:<RFQs/>,sourcing:<Sourcing/>,quotes:<Quotes/>,comparison:<Comparison/>,approvals:<Approvals/>,orders:<Orders/>,commissions:<Commissions/>,expenses:<Expenses/>,invoices:<Invoices/>,payments:<Payments/>,suppliers:<Suppliers/>,certificates:<Certificates/>,reports:<Reports/>,documents:<Documents/>,audit:<Audit/>,settings:<Settings/>}; return map[active];
}

function App(){const [active,setActive]=useState<ModuleKey>("dashboard");const [collapsed,setCollapsed]=useState(false);const [mobile,setMobile]=useState(false);const [query,setQuery]=useState("");const title=useMemo(()=>modules.flatMap(g=>g.items).find(i=>i.key===active)?.label||"Dashboard",[active]);
  function nav(k:ModuleKey){setActive(k);setMobile(false);window.scrollTo({top:0,behavior:"smooth"})}
  return <div className="app-shell"><aside className={`${collapsed?"collapsed":""} ${mobile?"mobile-open":""}`}><div className="side-brand"><span className="brand-mark">PF</span>{!collapsed&&<div><strong>ProcureFlow Agent</strong><small>Procurement & Commission</small></div>}<button className="mobile-close" onClick={()=>setMobile(false)}>×</button></div><nav>{modules.map(g=><div key={g.group}>{!collapsed&&<h6>{g.group}</h6>}{g.items.map(i=><button key={i.key} className={active===i.key?"active":""} onClick={()=>nav(i.key)} title={i.label}><i>{i.icon}</i>{!collapsed&&<span>{i.label}</span>}</button>)}</div>)}</nav><button className="collapse" onClick={()=>setCollapsed(!collapsed)}>{collapsed?"→":"←  Collapse sidebar"}</button></aside>{mobile&&<div className="mobile-overlay" onClick={()=>setMobile(false)}></div>}<div className="app-main"><header><button className="hamburger" onClick={()=>setMobile(true)}>☰</button><div className="breadcrumbs"><span>Workspace</span><b>/</b><strong>{title}</strong></div><div className="global-search">⌕<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search customers, RFQs, suppliers..."/>{query&&<div className="search-results"><strong>Quick results</strong><button onClick={()=>nav("rfqs")}>RFQ-2026-004 <small>SS316 Reactor Package</small></button><button onClick={()=>nav("customers")}>Bharat Process Systems <small>Customer</small></button><button onClick={()=>nav("suppliers")}>Apex Process Equipments <small>Supplier</small></button></div>}</div><button className="quick" onClick={()=>nav("rfqs")}>＋ Quick create</button><button className="notify">●<span>3</span></button><div className="user"><span>MS</span><div><strong>Manan Shastri</strong><small>Administrator</small></div></div></header><main><ModuleView active={active} navigate={nav}/></main><footer>ProcureFlow Agent · Supplier bills customer directly · Agent invoices contain confirmed commission and approved reimbursables only</footer></div></div>;
}

export default function Home(){const [loggedIn,setLoggedIn]=useState(false);return loggedIn?<App/>:<Login onLogin={()=>setLoggedIn(true)}/>}
